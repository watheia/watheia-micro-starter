---
title: Making Time for What's Important
subtitle: >-
  Negat esse eam, inquit, propter se expetendam. Ergo, si semel tristior
  effectus est, hilara vita amissa est.
date: '2020-05-30'
categories:
  - content/data/categories/tutorials.yaml
  - content/data/categories/news.yaml
tags:
  - content/data/tags/tips.yaml
excerpt: >-
  We often forget to make time on the calendar for the things and people that
  matter most. Make sure your calendar and task list reflect the personal calls
  and family time you need.
thumb_image: images/post-2.jpg
thumb_image_alt: Post 4 placeholder image
image: images/post-2.jpg
image_alt: Post 4 placeholder image
image_position: right
seo:
  title: Making Time for What's Important
  description: 'Itaque hoc frequenter dici solet a vobis, non intellegere nos'
  extra:
    - name: 'og:type'
      value: article
      keyName: property
    - name: 'og:title'
      value: Making Time for What's Important
      keyName: property
    - name: 'og:description'
      value: 'Itaque hoc frequenter dici solet a vobis, non intellegere nos'
      keyName: property
    - name: 'og:image'
      value: images/post-2.jpg
      keyName: property
      relativeUrl: true
    - name: 'twitter:card'
      value: summary_large_image
    - name: 'twitter:title'
      value: Making Time for What's Important
    - name: 'twitter:description'
      value: 'Itaque hoc frequenter dici solet a vobis, non intellegere nos'
    - name: 'twitter:image'
      value: images/post-2.jpg
      relativeUrl: true
layout: post
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Teneo, inquit, finem illi videri nihil dolere. Quid est enim aliud esse versutum. Age, inquies, ista parva sunt. Verum hoc idem saepe faciamus. Atque ab his initiis profecti omnium virtutum et originem et progressionem persecuti sunt. Duo Reges: constructio interrete. Itaque eos id agere, ut a se dolores, morbos, debilitates repellant. Estne, quaeso, inquam, sitienti in bibendo voluptas? Iam in altera philosophiae parte. Quem Tiberina descensio festo illo die tanto gaudio affecit, quanto L.

- Restinguet citius, si ardentem acceperit.
- Te enim iudicem aequum puto, modo quae dicat ille bene noris.
- Quid, quod homines infima fortuna, nulla spe rerum gerendarum, opifices denique delectantur historia?
- Quo minus animus a se ipse dissidens secumque discordans gustare partem ullam liquidae voluptatis et liberae potest.

**Quippe: habes enim a rhetoribus;** Vos autem cum perspicuis dubia debeatis illustrare, dubiis perspicua conamini tollere. Hoc dixerit potius Ennius: Nimium boni est, cui nihil est mali. Sic consequentibus vestris sublatis prima tolluntur. Negat esse eam, inquit, propter se expetendam. Ergo, si semel tristior effectus est, hilara vita amissa est.
