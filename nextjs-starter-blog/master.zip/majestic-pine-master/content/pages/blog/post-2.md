---
title: Managing a Team Productively
subtitle: >-
  Idemque diviserunt naturam hominis in animum et corpus. Si enim ad populum me
  vocas, eum.
date: '2020-05-25'
categories:
  - content/data/categories/news.yaml
  - content/data/categories/general.yaml
excerpt: >-
  How to handle multiple cross functional tasks and projects with App Land — the
  tools and tricks of the trade.
thumb_image: images/post-4.jpg
thumb_image_alt: Post 2 placeholder image
image: images/post-4.jpg
image_alt: Post 2 placeholder image
image_position: left
seo:
  title: Managing a Team Productively
  description: Quae diligentissime contra Aristonem dicuntur a Chryippo
  extra:
    - name: 'og:type'
      value: article
      keyName: property
    - name: 'og:title'
      value: Managing a Team Productively
      keyName: property
    - name: 'og:description'
      value: Quae diligentissime contra Aristonem dicuntur a Chryippo
      keyName: property
    - name: 'og:image'
      value: images/post-4.jpg
      keyName: property
      relativeUrl: true
    - name: 'twitter:card'
      value: summary_large_image
    - name: 'twitter:title'
      value: Managing a Team Productively
    - name: 'twitter:description'
      value: Quae diligentissime contra Aristonem dicuntur a Chryippo
    - name: 'twitter:image'
      value: images/post-4.jpg
      relativeUrl: true
layout: post
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Negat esse eam, inquit, propter se expetendam. Nam de isto magna dissensio est. Nullum inveniri verbum potest quod magis idem declaret Latine, quod Graece, quam declarat voluptas. Idemne potest esse dies saepius, qui semel fuit? Non est ista, inquam, Piso, magna dissensio. Ita multo sanguine profuso in laetitia et in victoria est mortuus. Quasi vero, inquit, perpetua oratio rhetorum solum, non etiam philosophorum sit. Duo Reges: constructio interrete.

Quae diligentissime contra Aristonem dicuntur a Chryippo. Videamus igitur sententias eorum, tum ad verba redeamus. Levatio igitur vitiorum magna fit in iis, qui habent ad virtutem progressionis aliquantum. Virtutis, magnitudinis animi, patientiae, fortitudinis fomentis dolor mitigari solet. Nihil enim hoc differt. Quorum sine causa fieri nihil putandum est.

## Sed Nimis Multa

An potest cupiditas finiri? Quamquam te quidem video minime esse deterritum. Sit, inquam, tam facilis, quam vultis, comparatio voluptatis, quid de dolore dicemus? Quae qui non vident, nihil umquam magnum ac cognitione dignum amaverunt.

> Ita est quoddam commune officium sapientis et insipientis, ex quo efficitur versari in iis, quae media dicamus.

Omnes enim iucundum motum, quo sensus hilaretur. Hoc est non dividere, sed frangere. Sed ne, dum huic obsequor, vobis molestus sim. Efficiens dici potest. Quia dolori non voluptas contraria est, sed doloris privatio. Quid dubitas igitur mutare principia naturae? Atqui eorum nihil est eius generis, ut sit in fine atque extrerno bonorum. Idemque diviserunt naturam hominis in animum et corpus. Si enim ad populum me vocas, eum. Sed tu istuc dixti bene Latine, parum plane.

Unum nescio, quo modo possit, si luxuriosus sit, finitas cupiditates habere. **Audeo dicere, inquit.** Perturbationes autem nulla naturae vi commoventur, omniaque ea sunt opiniones ac iudicia levitatis. Nunc haec primum fortasse audientis servire debemus. Nihil ad rem! Ne sit sane; Et certamen honestum et disputatio splendida! omnis est enim de virtutis dignitate contentio. Quonam, inquit, modo? Nullum inveniri verbum potest quod magis idem declaret Latine, quod Graece, quam declarat voluptas. Hoc ille tuus non vult omnibusque ex rebus voluptatem quasi mercedem exigit.

- Fortitudinis quaedam praecepta sunt ac paene leges, quae effeminari - virum vetant in dolore.
- Non igitur bene.

Maximas vero virtutes iacere omnis necesse est voluptate dominante.
