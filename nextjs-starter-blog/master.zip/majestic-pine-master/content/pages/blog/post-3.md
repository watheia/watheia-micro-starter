---
title: Using App Land For Travel
subtitle: >-
  Innumerabilia dici possunt in hanc sententiam, sed non necesse est. Putabam
  equidem satis, inquit, me dixisse.
date: '2020-05-28'
categories:
  - content/data/categories/general.yaml
excerpt: >-
  Planning a trip is easy with App Land — from itinerary to touristic
  attractions, shopping and fine dining, everything can be turned into a
  schedule and task list!
thumb_image: images/post-3.jpg
thumb_image_alt: Post 3 placeholder image
image: images/post-3.jpg
image_alt: Post 3 placeholder image
image_position: top
seo:
  title: Using App Land For Travel
  description: 'Quis est, qui non oderit libidinosam, protervam adolescentiam'
  extra:
    - name: 'og:type'
      value: article
      keyName: property
    - name: 'og:title'
      value: Using App Land For Travel
      keyName: property
    - name: 'og:description'
      value: 'Quis est, qui non oderit libidinosam, protervam adolescentiam'
      keyName: property
    - name: 'og:image'
      value: images/post-3.jpg
      keyName: property
      relativeUrl: true
    - name: 'twitter:card'
      value: summary_large_image
    - name: 'twitter:title'
      value: Using App Land For Travel
    - name: 'twitter:description'
      value: 'Quis est, qui non oderit libidinosam, protervam adolescentiam'
    - name: 'twitter:image'
      value: images/post-3.jpg
      relativeUrl: true
layout: post
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Non est ista, inquam, Piso, magna dissensio. Callipho ad virtutem nihil adiunxit nisi voluptatem, Diodorus vacuitatem doloris. Aut haec tibi, Torquate, sunt vituperanda aut patrocinium voluptatis repudiandum. Invidiosum nomen est, infame, suspectum. Dolor ergo, id est summum malum, metuetur semper, etiamsi non aderit; Duo Reges: constructio interrete. Innumerabilia dici possunt in hanc sententiam, sed non necesse est. Quae fere omnia appellantur uno ingenii nomine, easque virtutes qui habent, ingeniosi vocantur. Ut aliquid scire se gaudeant?

Quis est, qui non oderit libidinosam, protervam adolescentiam? Innumerabilia dici possunt in hanc sententiam, sed non necesse est. Putabam equidem satis, inquit, me dixisse. Quid igitur, inquit, eos responsuros putas? Age, inquies, ista parva sunt. Negabat igitur ullam esse artem, quae ipsa a se proficisceretur;

Cur ipse Pythagoras et Aegyptum lustravit et Persarum magos adiit? Ex ea difficultate illae fallaciloquae, ut ait Accius, malitiae natae sunt. Quorum sine causa fieri nihil putandum est. Sit enim idem caecus, debilis. Qui-vere falsone, quaerere mittimus-dicitur oculis se privasse; Intrandum est igitur in rerum naturam et penitus quid ea postulet pervidendum; Urgent tamen et nihil remittunt. Quae contraria sunt his, malane? Nihil acciderat ei, quod nollet, nisi quod anulum, quo delectabatur, in mari abiecerat. Atque his de rebus et splendida est eorum et illustris oratio. Haec para/doca illi, nos admirabilia dicamus. Non est ista, inquam, Piso, magna dissensio.
