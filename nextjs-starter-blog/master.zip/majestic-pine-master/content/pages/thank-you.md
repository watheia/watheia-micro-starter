---
title: Thank You
sections:
  - type: hero_section
    title: Thank You!
    subtitle: Thank you for testing the App template. Have a great day!
    actions:
      - label: Back to homepage
        url: /
        style: primary
    align: center
    padding_bottom: large
    background_color: none
layout: advanced
---
