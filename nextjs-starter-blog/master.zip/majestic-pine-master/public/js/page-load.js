window.onNextjsRouteChangeComplete = function() {
window.addMainNavigationHandlers();
window.addAnnouncementHandlers();
window.addVideoEmbedsHandlers();
};