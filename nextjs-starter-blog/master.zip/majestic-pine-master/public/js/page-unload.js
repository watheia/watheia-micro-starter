window.onNextjsRouteChangeStart = function() {
window.removeMainNavigationHandlers();
window.removeAnnouncementHandlers();
window.removeVideoEmbedsHandlers();
};