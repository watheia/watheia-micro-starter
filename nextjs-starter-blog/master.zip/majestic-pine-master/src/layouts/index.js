import advanced from './advanced';
import page from './page';
import post from './post';

export {
    advanced,
    page,
    post
};

export default {
    advanced,
    page,
    post
};
